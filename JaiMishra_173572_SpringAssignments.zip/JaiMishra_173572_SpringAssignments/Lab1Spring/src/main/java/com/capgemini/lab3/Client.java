package com.capgemini.lab3;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {

		ApplicationContext applicationcontext = new ClassPathXmlApplicationContext("emp3.xml");

		SBUbean sbu = (SBUbean) applicationcontext.getBean(SBUbean.class);
		System.out.println(sbu);

	}

}
