package com.capgemini.lab4;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);

		ApplicationContext appctx = new ClassPathXmlApplicationContext("emp4.xml");

		Employee emp = (Employee) appctx.getBean("list");

		System.out.println("Kindly Enter the Employee ID");
		int employeeid = scan.nextInt();

		for (Employee employee : emp.getEmployeeList())
			if (employeeid == employee.getEmployeeId())
				System.out.println(employee);

	}

}
