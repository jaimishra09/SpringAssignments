package com.capgemini.lab3;

import java.util.List;

public class SBUbean {
	
	public SBUbean() {
		// TODO Auto-generated constructor stub
	}

	private int SBUid;

	private String SBUname;

	private String SBUhead;

	private List<Employee> employeeList;

	public List<Employee> getEmpList() {
		return employeeList;
	}

	public void setEmpList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}

	public SBUbean(int sBUid, String sBUname, String sBUhead, List<Employee> employeeList) {
		super();
		SBUid = sBUid;
		SBUname = sBUname;
		SBUhead = sBUhead;
		this.employeeList = employeeList;
	}

	public int getSBUid() {
		return SBUid;
	}

	public void setSBUid(int sBUid) {
		SBUid = sBUid;
	}

	public String getSBUname() {
		return SBUname;
	}

	public void setSBUname(String sBUname) {
		SBUname = sBUname;
	}

	public String getSBUhead() {
		return SBUhead;
	}

	public void setSBUhead(String sBUhead) {
		SBUhead = sBUhead;
	}

	public List<Employee> getEmployeeList() {
		return employeeList;
	}

	public void setEmployeeList(List<Employee> employeeList) {
		this.employeeList = employeeList;
	}

	@Override
	public String toString() {
		return "SBUbean [SBUid=" + SBUid + ", SBUname=" + SBUname + ", SBUhead=" + SBUhead + ", employeeList="
				+ employeeList + "]";
	}
	
	

	
}
