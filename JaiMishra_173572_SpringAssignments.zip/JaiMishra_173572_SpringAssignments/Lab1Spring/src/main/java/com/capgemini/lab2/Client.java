package com.capgemini.lab2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		ApplicationContext appctx = new ClassPathXmlApplicationContext("emp2.xml");
		
		
		Employee employee = appctx.getBean(Employee.class);
		
		System.out.println(employee);

	}

}
