package com.capgemini.lab1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.lab1.Employee;

public class Client {

	public static void main(String[] args) {

		@SuppressWarnings("resource")
		ApplicationContext ctx = new ClassPathXmlApplicationContext("emp1.xml");

		Employee empObj =  ctx.getBean(Employee.class);

		System.out.println(empObj);

	}

}
