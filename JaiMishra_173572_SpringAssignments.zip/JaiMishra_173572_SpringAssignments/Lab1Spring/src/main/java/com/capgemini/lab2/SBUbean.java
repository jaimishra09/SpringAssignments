package com.capgemini.lab2;

public class SBUbean {

	@Override
	public String toString() {
		return "SBUbean [SBUid=" + SBUid + ", SBUnamee=" + SBUnamee + ", SBUhead=" + SBUhead + "]";
	}

	private int SBUid;

	private String SBUnamee;

	private String SBUhead;

	public int getSBUid() {
		return SBUid;
	}

	public void setSBUid(int sBUid) {
		SBUid = sBUid;
	}

	public String getSBUnamee() {
		return SBUnamee;
	}

	public void setSBUnamee(String sBUnamee) {
		SBUnamee = sBUnamee;
	}

	public String getSBUhead() {
		return SBUhead;
	}

	public void setSBUhead(String sBUhead) {
		SBUhead = sBUhead;
	}
	
	public SBUbean() {
		// TODO Auto-generated constructor stub
	}

	public SBUbean(int sBUid, String sBUnamee, String sBUhead) {
		super();
		SBUid = sBUid;
		SBUnamee = sBUnamee;
		SBUhead = sBUhead;
	}
	
	

	
}
