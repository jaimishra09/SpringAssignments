package com.cg.repo;

import java.util.List;

import com.cg.entities.Product;

public interface ProductRepo {
	

	Product saveProduct(Product product);
	
	
	List<Product> getAll();
}
