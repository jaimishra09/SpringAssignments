package com.cg.service;

import com.cg.entity.Trainee;

public interface TraineeInterface {
	
	public String deleteTrainee(int id);
	
	Iterable<Trainee> retrieveAll();

	void addTrainee(Trainee trainee);

	
	
	
	
}
