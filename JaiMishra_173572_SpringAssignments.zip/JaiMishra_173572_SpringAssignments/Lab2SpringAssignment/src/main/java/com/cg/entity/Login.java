package com.cg.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Login {
	
	public Login() {
		// TODO Auto-generated constructor stub
	}

	@Id
	private String traineeId;
	private String password;
	
	public String getUserName() {
		return traineeId;
	}
	public void setUserName(String userName) {
		this.traineeId = traineeId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	

}
