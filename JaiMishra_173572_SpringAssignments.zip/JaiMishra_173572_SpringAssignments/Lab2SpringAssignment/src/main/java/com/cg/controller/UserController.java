package com.cg.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.entity.Login;
import com.cg.entity.Trainee;
import com.cg.service.TraineeInterface;

@Scope("session")
@Controller
public class UserController {
	
	List<String> LocationDetails;
	List<String> DomainDetails;

	@Autowired
	private TraineeInterface service;
	

	@RequestMapping("/home")
	public String homePage(Model model) {
		model.addAttribute("login", new Login());
		return "login";
	}
	
	

	@RequestMapping("/retrieveAlltrainees")
	public String retrieveAllTrainee(Model model) {
		List<Trainee> list = null;
		model.addAttribute("list", list);
		return "retrieveAlltheTrainees";
	}
	
	

	@RequestMapping("/checkTraineeLogin")
	public String checkLogin(Login login, Model model) {
		String invalid = "Enter correct Details";
		model.addAttribute("invalid", invalid);
		return "AddaTrainee";
	}
	
	

	@RequestMapping("/retrieveTrainee")
	public String retrieveTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "retrieveTrainee";
	}
	
	

	@RequestMapping(path = "add")
	public String save(@ModelAttribute("trainee") Trainee trainee, Model model) {

		service.addTrainee(trainee);
		model.addAttribute("login", new Login());
		return "total";
	}
	
	

	@RequestMapping("/addTrainee")
	public String addtrainee(Model model) {
		LocationDetails = new ArrayList<String>();

		LocationDetails.add("Mumbai");
		LocationDetails.add("Pune");
		LocationDetails.add("Chennai");
		LocationDetails.add("Bangalore");

		DomainDetails = new ArrayList<String>();

		DomainDetails.add("Java");
		DomainDetails.add("Struts");
		DomainDetails.add("Hibernate");
		DomainDetails.add("Spring");

		model.addAttribute("DomainDetails", DomainDetails);
		model.addAttribute("LocationDetails", LocationDetails);

		model.addAttribute("trainee", new Trainee());

		return "trainee";

	}
	
	

	@RequestMapping("/deleteTrainee")
	public String deleteTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "deleteTrainee ";

	}
	
	

	@RequestMapping("/modifyTrainee")
	public String modifyTrainee(Model model) {
		model.addAttribute("trainee", new Trainee());
		return "modifyaTrainee ";

	}

}